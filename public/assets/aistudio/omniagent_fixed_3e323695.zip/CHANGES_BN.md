# OmniAgent — কী ঠিক হলো / কী নতুন

## ঠিক করা (bug)
1. **Barge-in কাজ করত না** — এজেন্ট কথা বলার সময় মাইক বন্ধ হয়ে যেত। এখন মাইক সবসময় খোলা (Echo Canceller সহ), আপনি বললেই সাথে সাথে থেমে যায়।
2. **ডিফল্ট মোডে মাইকই স্ট্রিম হতো না** (শুধু DIRECT মোডে হতো)। এখন সবসময় Live WebSocket।
3. **পুরনো মডেল** `gemini-2.0-flash-exp` বন্ধ। এখন নতুন Live মডেল + অটো-ফলব্যাক লিস্ট।
4. **ফোন কন্ট্রোল (tool) আসলে সেটআপেই ছিল না।** এখন `phone_action` function-call রেজিস্টার; Gemini নিজে ফোনে কাজ করে রেজাল্ট ফেরত পায়।
5. **দুই ভয়েস একসাথে** (পুরনো STT/TTS + Live audio) — Live চলার সময় পুরনোটা বন্ধ।
6. রিকানেক্ট, goAway হ্যান্ডেল, error মেসেজ স্ক্রিনে দেখায়।
7. ইউজারের কথা (YOU) ও এজেন্টের কথা (ARCHER) transcript-এ লাইভ আসে।

## UI
- স্ক্রিন ভরা Live HUD বাদ → একটা পাতলা `LiveCompactBar` (নতুন ফাইল)।
- অতিরিক্ত টেলিমেট্রি/মেসেজ-বার সারি বাদ (স্ক্রিনশটের ডিজাইনের মতো পরিষ্কার)।

## APK সাইজ
- Debug + Release দুটোতেই R8 minify + resource shrink চালু।

## বদলানো ফাইল
- service/MultimodalLiveService.kt
- viewmodel/OmniAgentViewModel.kt
- ui/screens/AgentCommandScreen.kt
- ui/components/LiveCompactBar.kt (নতুন)
- app/build.gradle.kts, app/proguard-rules.pro

## গ্লোব = Gemini Live (মেইন)
- গ্লোবে চাপ → Gemini Live চালু, আবার চাপ/STOP → বন্ধ।
- গ্লোব অ্যানিমেশন Live-এর অবস্থা (শুনছি/বলছে) অনুযায়ী চলে।
- শুধু মাইক পারমিশন লাগে (ক্যামেরা ঐচ্ছিক)।
