package com.example.service

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.util.Base64
import android.util.Log
import androidx.core.content.ContextCompat
import com.google.firebase.Firebase
import com.google.firebase.FirebaseApp
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

private const val TAG = "MultimodalLiveService"

enum class LiveConnectionEngine(
    val id: String,
    val badgeText: String,
    val labelBn: String
) {
    AUTO_HYBRID(
        id = "auto_hybrid",
        badgeText = "AUTO HYBRID (GEMINI 2.0 + CLOUD)",
        labelBn = "অটো হাইব্রিড: Gemini Live WebSocket ও বিল্ট-ইন স্ট্রিমিং একসাথে চলবে"
    ),
    BUILTIN_FIREBASE_STREAM(
        id = "builtin_stream",
        badgeText = "BUILT-IN AI STREAM",
        labelBn = "বিল্ট-ইন ক্লাউড মাল্টিমোডাল স্ট্রিমিং (আলাদা কি ছাড়াই কাজ করবে)"
    ),
    DIRECT_WEBSOCKET_BIDI(
        id = "direct_ws_bidi",
        badgeText = "GEMINI 2.0 BIDI WEBSOCKET",
        labelBn = "ডাইরেক্ট BidiGenerateContent ওয়েবসকেট (models/gemini-2.0-flash-exp)"
    )
}

data class MultimodalLiveExportConfig(
    val builtInFirebaseApiKey: String = "",
    val customUserApiKey: String = "",
    val effectiveApiKey: String = "",
    val projectId: String = "",
    val applicationId: String = "",
    val packageName: String = "",
    val certSha1: String = "",
    val websocketBidiEndpoint: String =
        "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent",
    val fullWebsocketUrlWithKey: String = "",
    val restStreamEndpoint: String =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:streamGenerateContent?alt=sse",
    val activeLiveModel: String = "models/gemini-2.0-flash-exp",
    val fallbackStreamModel: String = "gemini-3.8-flash",
    val setupHandshakeJson: String = "",
    val setupPayloadJson: String = "",
    val toolsDeclarationJson: String = "",
    val realtimeFramePayloadSample: String = "",
    val pythonLiveClientCode: String = ""
)

data class MultimodalLiveSessionState(
    val isLiveActive: Boolean = false,
    val connectionEngine: LiveConnectionEngine = LiveConnectionEngine.AUTO_HYBRID,
    val engineMode: LiveConnectionEngine = LiveConnectionEngine.AUTO_HYBRID,
    val connectionStatusLabel: String = "STANDBY • READY FOR GEMINI 2.0 LIVE",
    val isWebSocketConnected: Boolean = false,
    val isMicMuted: Boolean = false,
    val isCameraStreamEnabled: Boolean = true,
    val isScreenStreamEnabled: Boolean = true,
    val isRealTimeToolsArmed: Boolean = true,
    val isToolsArmed: Boolean = true,
    val isAgentSpeakingLive: Boolean = false,
    val isUserSpeakingBargeIn: Boolean = false,
    val streamedCameraFrames: Int = 0,
    val streamedScreenFrames: Int = 0,
    val framesSentCount: Int = 0,
    val fpsTelemetry: String = "LIVE 24kHz PCM • 1.5 FPS VISION",
    val streamedAudioPackets: Int = 0,
    val executedLiveActionsCount: Int = 0,
    val bargeInInterruptCount: Int = 0,
    val lastVisualInsight: String = "ক্যামেরা ও পার্মানেন্ট স্ক্রিন ভিশন সক্রিয়",
    val audioWaveformLevels: List<Float> = listOf(
        0.22f, 0.38f, 0.54f, 0.30f, 0.68f, 0.82f, 0.45f, 0.60f,
        0.75f, 0.42f, 0.58f, 0.85f, 0.50f, 0.36f, 0.62f, 0.28f
    ),
    val lastLiveToolSummary: String = "লাইভ ভয়েস, ক্যামেরা ও পার্মানেন্ট স্ক্রিন কন্ট্রোল প্রস্তুত",
    val lastToolExecuted: String = "লাইভ ভয়েস, ক্যামেরা ও ৪-দিকের স্ক্রিন কন্ট্রোল প্রস্তুত",
    val lastCopiedLabel: String = "",
    val liveStreamingPartialReply: String = "",
    val activeModelName: String = "models/gemini-2.0-flash-exp",
    val statusMessageBn: String = "Gemini Live (BidiGenerateContent) প্রস্তুত — কথা বললেই সাথে সাথে উত্তর ও বার্জ-ইন",
    val exportConfig: MultimodalLiveExportConfig = MultimodalLiveExportConfig()
)

class MultimodalLiveService(
    private val context: Context,
    private val onLiveSpokenChunkOrReply: (textChunk: String, isFinalTurn: Boolean) -> Unit,
    private val onExecuteLiveActionTag: (userUtterance: String, rawAiResponse: String) -> Unit,
    private val onBargeInInterruptRequested: () -> Unit,
    private val onUserTranscript: (String) -> Unit = {}
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(MultimodalLiveSessionState())
    val state: StateFlow<MultimodalLiveSessionState> = _state.asStateFlow()

    @Volatile
    private var latestCameraBitmap: Bitmap? = null

    @Volatile
    private var latestScreenBitmap: Bitmap? = null

    private var framePumpJob: Job? = null
    private var activeStreamTurnJob: Job? = null
    private var audioRecordPumpJob: Job? = null
    private var activeWebSocket: WebSocket? = null
    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }

    // Persistent 24kHz PCM streaming AudioTrack for low-latency Gemini Live audio output & instant barge-in flush
    private val audioTrackLock = Any()
    private var liveOutputAudioTrack: AudioTrack? = null

    // Primary Gemini 2.0 Flash Exp model for WebSocket BidiGenerateContent
    // Live model candidates: if one is rejected before setup completes, the next one is tried automatically.
    private val liveModelCandidates = listOf(
        "models/gemini-3.1-flash-live-preview",
        "models/gemini-2.5-flash-native-audio-preview-09-2025",
        "models/gemini-live-2.5-flash-preview"
    )
    @Volatile private var modelIndex = 0
    private val wsBidiModel: String get() = liveModelCandidates[modelIndex.coerceIn(0, liveModelCandidates.size - 1)]
    @Volatile private var setupDone = false
    private var reconnectAttempts = 0
    private var toolCallHandler: (suspend (String) -> String)? = null
    private val userTurnBuf = StringBuilder()
    private val modelTurnBuf = StringBuilder()

    fun setToolCallHandler(handler: suspend (String) -> String) {
        toolCallHandler = handler
    }

    private val firebaseFastLiveModel by lazy {
        val cfg = generationConfig {
            temperature = 0.65f
            maxOutputTokens = 450
        }
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = cfg,
            systemInstruction = content {
                text(LIVE_MULTIMODAL_SYSTEM_PROMPT)
            }
        )
    }

    private val firebaseLiveStreamModel by lazy {
        val cfg = generationConfig {
            temperature = 0.7f
            maxOutputTokens = 650
        }
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = cfg,
            systemInstruction = content {
                text(LIVE_MULTIMODAL_SYSTEM_PROMPT)
            }
        )
    }

    init {
        val permReady = ScreenCaptureSessionBus.syncSavedPreference(context)
        if (permReady) {
            _state.value = _state.value.copy(isScreenStreamEnabled = true)
        }
        refreshExportConfig(customApiKey = "")
    }

    private fun buildSetupJson(): String = JSONObject().apply {
        put("setup", JSONObject().apply {
            put("model", wsBidiModel)
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Charon"))))
            })
            put("systemInstruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", LIVE_MULTIMODAL_SYSTEM_PROMPT))))
            put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().put(
                JSONObject().apply {
                    put("name", "phone_action")
                    put("description", "Control the user's phone: open apps, call, toggle settings, volume, tap/scroll/swipe the screen, read the screen, play music. Call this whenever the user asks you to DO something on the phone.")
                    put("parameters", JSONObject().apply {
                        put("type", "OBJECT")
                        put("properties", JSONObject().apply {
                            put("action", JSONObject().put("type", "STRING").put("description",
                                "One of: OPEN_APP, TOGGLE_SYSTEM_SETTING, SET_VOLUME, SCAN_CONTACT_OR_SCREEN, SCREEN_UI_CONTROL, PLAY_MUSIC, STOP_MUSIC, DIAL_NUMBER, OPEN_SETTINGS, INSTALL_APP_PLAYSTORE"))
                            put("target", JSONObject().put("type", "STRING").put("description",
                                "App name / setting name (WIFI, BLUETOOTH, MOBILE_DATA, FLASHLIGHT...) / contact / button text / song"))
                            put("extra", JSONObject().put("type", "STRING").put("description",
                                "ON, OFF, 0-100, UP, DOWN, CALL, WHATSAPP, CLICK, SCROLL_DOWN, SCROLL_UP, SWIPE_LEFT, SWIPE_RIGHT, READ_SCREEN..."))
                        })
                        put("required", JSONArray().put("action"))
                    })
                }
            ))))
            put("inputAudioTranscription", JSONObject())
            put("outputAudioTranscription", JSONObject())
        })
    }.toString()

    /**
     * Extracts the real built-in Firebase Gemini API key, Project ID, App ID, Package Name,
     * and constructs the complete Gemini Multimodal Live API (`BidiGenerateContent` with `models/gemini-2.0-flash-exp`)
     * configuration so the user can view, copy, export, or connect with either Built-In or Custom API keys.
     */
    fun refreshExportConfig(customApiKey: String) {
        val cleanCustom = customApiKey.trim()
        var firebaseKey = ""
        var projectId = ""
        var appId = ""
        try {
            val opts = FirebaseApp.getInstance().options
            firebaseKey = opts.apiKey.orEmpty()
            projectId = opts.projectId.orEmpty()
            appId = opts.applicationId.orEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseApp options read warning: ${e.message}")
        }

        val effectiveKey = cleanCustom.ifBlank { firebaseKey }
        val pkgName = context.packageName
        val wsBase =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
        val fullWs = if (effectiveKey.isNotBlank()) {
            "$wsBase?key=$effectiveKey"
        } else {
            "$wsBase?key=YOUR_GEMINI_LIVE_API_KEY"
        }

        val setupJson = buildSetupJson()

        val toolsJson = JSONObject().apply {
            put(
                "functionDeclarations",
                JSONArray().apply {
                    put(JSONObject().put("name", "toggle_system_setting").put("description", "Turn ON/OFF Wi-Fi, Bluetooth, SIM Mobile Data, Airplane Mode, Hotspot, Location, Torch"))
                    put(JSONObject().put("name", "set_volume").put("description", "Control Media, Ring, Alarm, Call, Notification, System volume 0-100%"))
                    put(JSONObject().put("name", "screen_ui_control").put("description", "Click, scroll, or swipe UP, DOWN, LEFT, RIGHT on the live screen"))
                    put(JSONObject().put("name", "scan_contact_or_screen").put("description", "Find a contact on screen or in Contacts and call or message"))
                }
            )
        }.toString(2)

        val frameSample = JSONObject().apply {
            put(
                "realtimeInput",
                JSONObject().apply {
                    put(
                        "mediaChunks",
                        JSONArray().apply {
                            put(
                                JSONObject().apply {
                                    put("mimeType", "audio/pcm;rate=16000")
                                    put("data", "<BASE64_16KHZ_MONO_PCM_AUDIO>")
                                }
                            )
                            put(
                                JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", "<BASE64_CAMERA_OR_SCREEN_JPEG_FRAME>")
                                }
                            )
                        }
                    )
                }
            )
        }.toString(2)

        val pythonSnippet = """
            # ARCHER AI — Gemini Multimodal Live API (BidiGenerateContent • gemini-2.0-flash-exp)
            # Supports Real-Time Voice + Camera Video + Live Screen Share + Instant Barge-In
            import asyncio, json, base64, websockets

            API_KEY = "${effectiveKey.ifBlank { "PASTE_YOUR_GEMINI_API_KEY" }}"
            WS_URL = f"$wsBase?key={API_KEY}"

            async def run_archer_live_session():
                async with websockets.connect(WS_URL) as ws:
                    setup_msg = {
                        "setup": {
                            "model": "$wsBidiModel",
                            "generationConfig": {
                                "responseModalities": ["AUDIO"],
                                "temperature": 0.7
                            }
                        }
                    }
                    await ws.send(json.dumps(setup_msg))
                    print("ARCHER Multimodal Live API (gemini-2.0-flash-exp) Connected!")
                    async for raw_msg in ws:
                        data = json.loads(raw_msg)
                        print("Live Event:", data)

            if __name__ == "__main__":
                asyncio.run(run_archer_live_session())
        """.trimIndent()

        val newExport = MultimodalLiveExportConfig(
            builtInFirebaseApiKey = firebaseKey,
            customUserApiKey = cleanCustom,
            effectiveApiKey = effectiveKey,
            projectId = projectId,
            applicationId = appId,
            packageName = pkgName,
            websocketBidiEndpoint = wsBase,
            fullWebsocketUrlWithKey = fullWs,
            activeLiveModel = wsBidiModel,
            setupHandshakeJson = setupJson,
            setupPayloadJson = setupJson,
            toolsDeclarationJson = toolsJson,
            realtimeFramePayloadSample = frameSample,
            pythonLiveClientCode = pythonSnippet
        )

        _state.value = _state.value.copy(exportConfig = newExport)
    }

    fun copyToClipboard(label: String, text: String): String {
        return try {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText(label, text))
            _state.value = _state.value.copy(lastCopiedLabel = label)
            "জি স্যার, '$label' ক্লিপবোর্ডে কপি করা হয়েছে!"
        } catch (e: Exception) {
            "কপি করতে সমস্যা হয়েছে: ${e.message}"
        }
    }

    fun setEngineMode(engine: LiveConnectionEngine) {
        _state.value = _state.value.copy(
            connectionEngine = engine,
            engineMode = engine,
            statusMessageBn = engine.labelBn
        )
    }

    fun updateLatestCameraFrame(bitmap: Bitmap) {
        latestCameraBitmap = bitmap
        if (_state.value.isLiveActive && _state.value.isCameraStreamEnabled) {
            val nextCam = _state.value.streamedCameraFrames + 1
            val totalFrames = nextCam + _state.value.streamedScreenFrames
            _state.value = _state.value.copy(
                streamedCameraFrames = nextCam,
                framesSentCount = totalFrames
            )
        }
    }

    fun updateLatestScreenFrame(bitmap: Bitmap) {
        latestScreenBitmap = bitmap
        if (_state.value.isLiveActive && _state.value.isScreenStreamEnabled) {
            val nextScr = _state.value.streamedScreenFrames + 1
            val totalFrames = _state.value.streamedCameraFrames + nextScr
            _state.value = _state.value.copy(
                streamedScreenFrames = nextScr,
                framesSentCount = totalFrames
            )
        }
    }

    fun startLiveSession(customApiKey: String) {
        modelIndex = 0
        reconnectAttempts = 0
        setupDone = false
        refreshExportConfig(customApiKey)
        val engine = _state.value.connectionEngine
        _state.value = _state.value.copy(
            isLiveActive = true,
            connectionStatusLabel = "LIVE STREAMING • GEMINI LIVE",
            activeModelName = wsBidiModel,
            statusMessageBn = "জি স্যার, Gemini Live সচল! ভয়েস স্ট্রিমিং, ইনস্ট্যান্ট বার্জ-ইন ও লাইভ স্ক্রিন শেয়ারিং চলছে।"
        )

        if (true) {  // always use the direct Live WebSocket (the only path with real voice + barge-in)
            connectDirectBidiWebSocketIfPossible()
        }

        startFrameCapturePump()
        startRealTimeAudioRecordPump()
    }

    fun stopLiveSession() {
        framePumpJob?.cancel()
        framePumpJob = null
        audioRecordPumpJob?.cancel()
        audioRecordPumpJob = null
        activeStreamTurnJob?.cancel()
        activeStreamTurnJob = null
        stopAndFlushLiveAudioTrack()
        disconnectWebSocket()
        _state.value = _state.value.copy(
            isLiveActive = false,
            isWebSocketConnected = false,
            isAgentSpeakingLive = false,
            isUserSpeakingBargeIn = false,
            connectionStatusLabel = "STANDBY • READY FOR GEMINI 2.0 LIVE",
            liveStreamingPartialReply = "",
            statusMessageBn = "লাইভ মাল্টিমোডাল সেশন বন্ধ করা হয়েছে।"
        )
    }

    fun toggleMicMute(): Boolean {
        val next = !_state.value.isMicMuted
        _state.value = _state.value.copy(
            isMicMuted = next,
            statusMessageBn = if (next) "লাইভ মাইক্রোফোন মিউট করা হয়েছে" else "লাইভ মাইক্রোফোন আনমিউট করা হয়েছে"
        )
        return next
    }

    fun toggleCameraStream(): Boolean {
        val next = !_state.value.isCameraStreamEnabled
        _state.value = _state.value.copy(
            isCameraStreamEnabled = next,
            statusMessageBn = if (next) "লাইভ ক্যামেরা ভিশন স্ট্রিম চালু হয়েছে" else "লাইভ ক্যামেরা ভিশন স্ট্রিম বন্ধ করা হয়েছে"
        )
        return next
    }

    fun enableScreenStreamNow() {
        _state.value = _state.value.copy(
            isScreenStreamEnabled = true,
            statusMessageBn = "পার্মানেন্ট লাইভ স্ক্রিন শেয়ারিং চালু হয়েছে — এজেন্ট এখন সরাসরি আপনার স্ক্রিন দেখছে"
        )
        ScreenCaptureSessionBus.captureBestAvailableScreenFrame { bmp ->
            updateLatestScreenFrame(bmp)
            if (_state.value.isLiveActive && _state.value.isWebSocketConnected) {
                sendRealtimeImageFrameOverWs(bmp)
            }
        }
    }

    fun toggleScreenStream(): Boolean {
        val next = !_state.value.isScreenStreamEnabled
        _state.value = _state.value.copy(
            isScreenStreamEnabled = next,
            statusMessageBn = if (next) "লাইভ স্ক্রিন শেয়ারিং চালু হয়েছে" else "লাইভ স্ক্রিন শেয়ারিং বন্ধ করা হয়েছে"
        )
        if (next) {
            ScreenCaptureSessionBus.captureBestAvailableScreenFrame { bmp ->
                updateLatestScreenFrame(bmp)
            }
        }
        return next
    }

    fun toggleToolsArmed(): Boolean {
        val next = !_state.value.isRealTimeToolsArmed
        _state.value = _state.value.copy(
            isRealTimeToolsArmed = next,
            isToolsArmed = next,
            statusMessageBn = if (next) {
                "লাইভ ডিভাইস কন্ট্রোল ও ৪-দিকের স্ক্রিন অ্যাকশন চালু আছে"
            } else {
                "লাইভ ডিভাইস কন্ট্রোল পজ করা হয়েছে"
            }
        )
        return next
    }

    /**
     * Barge-in (Instant Interruption):
     * Immediately halts any ongoing AI audio stream (`AudioTrack` flush + stop), cancels
     * in-flight generation, and switches to listening for the user's new speech.
     */
    fun triggerBargeInInterrupt() {
        activeStreamTurnJob?.cancel()
        activeStreamTurnJob = null
        stopAndFlushLiveAudioTrack()
        _state.value = _state.value.copy(
            isAgentSpeakingLive = false,
            isUserSpeakingBargeIn = true,
            bargeInInterruptCount = _state.value.bargeInInterruptCount + 1,
            liveStreamingPartialReply = "",
            statusMessageBn = "জি স্যার, বলুন—আমি সাথে সাথে চুপ হয়ে আপনার কথা শুনছি..."
        )
        onBargeInInterruptRequested()
    }

    fun notifyAgentSpeechState(isSpeaking: Boolean) {
        if (_state.value.isAgentSpeakingLive != isSpeaking) {
            _state.value = _state.value.copy(
                isAgentSpeakingLive = isSpeaking,
                isUserSpeakingBargeIn = if (isSpeaking) false else _state.value.isUserSpeakingBargeIn
            )
        }
    }

    fun recordLiveToolExecution(summaryBn: String) {
        _state.value = _state.value.copy(
            executedLiveActionsCount = _state.value.executedLiveActionsCount + 1,
            lastLiveToolSummary = summaryBn,
            lastToolExecuted = summaryBn
        )
    }

@SuppressLint("MissingPermission")
    private fun startRealTimeAudioRecordPump() {
        audioRecordPumpJob?.cancel()
        audioRecordPumpJob = scope.launch {
            var tick = 0
            while (isActive && _state.value.isLiveActive) {
                tick++
                if (tick % 4 == 0 && !_state.value.isMicMuted) {
                    val base = if (_state.value.isAgentSpeakingLive) 0.55f else 0.28f
                    val levels = List(16) { idx ->
                        (base + kotlin.math.sin((tick + idx) * 0.65).toFloat() * 0.25f).coerceIn(0.14f, 0.95f)
                    }
                    _state.value = _state.value.copy(audioWaveformLevels = levels)
                }
                val ready = _state.value.isWebSocketConnected && setupDone && !_state.value.isMicMuted
                val hasMicPerm = ContextCompat.checkSelfPermission(
                    context, android.Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (!ready || !hasMicPerm) { delay(200L); continue }

                val sampleRate = 16000
                val minBuf = AudioRecord.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(3200)
                val recorder = try {
                    AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
                } catch (e: Exception) { delay(500L); continue }
                if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                    try { recorder.release() } catch (_: Exception) {}
                    delay(500L); continue
                }

                var aec: android.media.audiofx.AcousticEchoCanceler? = null
                var ns: android.media.audiofx.NoiseSuppressor? = null
                try {
                    // Echo cancellation: lets the mic stay OPEN while the agent talks (needed for barge-in)
                    if (android.media.audiofx.AcousticEchoCanceler.isAvailable()) {
                        aec = android.media.audiofx.AcousticEchoCanceler.create(recorder.audioSessionId)?.also { it.enabled = true }
                    }
                    if (android.media.audiofx.NoiseSuppressor.isAvailable()) {
                        ns = android.media.audiofx.NoiseSuppressor.create(recorder.audioSessionId)?.also { it.enabled = true }
                    }
                } catch (_: Exception) {}
                val aecActive = aec?.enabled == true

                val buf = ShortArray(800) // 50ms @16kHz
                var loudFrames = 0
                try {
                    recorder.startRecording()
                    // NOTE: mic is streamed continuously, even while the agent is speaking.
                    while (isActive && _state.value.isLiveActive && _state.value.isWebSocketConnected &&
                        setupDone && !_state.value.isMicMuted) {
                        val n = recorder.read(buf, 0, buf.size)
                        if (n <= 0) { delay(10L); continue }
                        var sum = 0.0
                        for (i in 0 until n) { val v = buf[i].toDouble(); sum += v * v }
                        val rms = sqrt(sum / n)
                        // Local instant barge-in (only trusted when echo cancellation is active)
                        if (aecActive && _state.value.isAgentSpeakingLive && rms > 2200.0) {
                            loudFrames++
                            if (loudFrames >= 3) { loudFrames = 0; localBargeIn() }
                        } else loudFrames = 0
                        val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until n) bb.putShort(buf[i])
                        sendRealtimeAudioChunkOverWs(bb.array())
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Mic stream paused: ${e.message}")
                } finally {
                    try { recorder.stop() } catch (_: Exception) {}
                    try { recorder.release() } catch (_: Exception) {}
                    try { aec?.release() } catch (_: Exception) {}
                    try { ns?.release() } catch (_: Exception) {}
                }
            }
        }
    }

    private fun localBargeIn() {
        stopAndFlushLiveAudioTrack()
        _state.value = _state.value.copy(
            isAgentSpeakingLive = false,
            isUserSpeakingBargeIn = true,
            bargeInInterruptCount = _state.value.bargeInInterruptCount + 1
        )
        onBargeInInterruptRequested()
    }

    private fun startFrameCapturePump() {
        framePumpJob?.cancel()
        framePumpJob = scope.launch {
            while (isActive && _state.value.isLiveActive) {
                if (_state.value.isScreenStreamEnabled) {
                    ScreenCaptureSessionBus.captureBestAvailableScreenFrame { bmp ->
                        updateLatestScreenFrame(bmp)
                        if (_state.value.isWebSocketConnected) {
                            sendRealtimeImageFrameOverWs(bmp)
                        }
                    }
                }
                if (_state.value.isCameraStreamEnabled && _state.value.isWebSocketConnected) {
                    latestCameraBitmap?.let { camBmp ->
                        sendRealtimeImageFrameOverWs(camBmp)
                    }
                }
                delay(1000L)
            }
        }
    }

private fun connectDirectBidiWebSocketIfPossible() {
        val url = _state.value.exportConfig.fullWebsocketUrlWithKey
        if (url.isBlank() || url.endsWith("YOUR_GEMINI_LIVE_API_KEY")) {
            _state.value = _state.value.copy(
                statusMessageBn = "Gemini API Key দেননি — সেটিংস থেকে আপনার AI Studio key দিন"
            )
            return
        }
        scope.launch {
            disconnectWebSocket()
            setupDone = false
            val request = Request.Builder().url(url).build()
            activeWebSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    activeWebSocket = webSocket
                    _state.value = _state.value.copy(
                        isWebSocketConnected = true,
                        connectionStatusLabel = "CONNECTING • $wsBidiModel",
                        activeModelName = wsBidiModel
                    )
                    webSocket.send(buildSetupJson())
                }

                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (text.isNotBlank()) handleIncomingWebSocketJson(text)
                }

                override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                    val t = try { bytes.utf8() } catch (_: Exception) { "" }
                    if (t.trimStart().startsWith("{")) handleIncomingWebSocketJson(t)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    handleSocketDown(webSocket, "${t.message ?: "network error"}")
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    try { webSocket.close(code, reason) } catch (_: Exception) {}
                    handleSocketDown(webSocket, "$code $reason")
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    handleSocketDown(webSocket, "$code $reason")
                }
            })
        }
    }

    private fun handleSocketDown(ws: WebSocket, reason: String) {
        if (ws !== activeWebSocket) return          // stale socket
        val wasSetup = setupDone
        setupDone = false
        activeWebSocket = null
        _state.value = _state.value.copy(isWebSocketConnected = false, isAgentSpeakingLive = false)
        stopAndFlushLiveAudioTrack()
        if (!_state.value.isLiveActive) return
        Log.w(TAG, "Live socket down (setup=$wasSetup): $reason")
        scope.launch {
            if (!wasSetup && modelIndex < liveModelCandidates.size - 1) {
                modelIndex++                              // model rejected -> try next candidate
            } else if (reconnectAttempts >= 5) {
                _state.value = _state.value.copy(
                    statusMessageBn = "লাইভ সংযোগ হয়নি: ${reason.take(70)} (API key / ইন্টারনেট দেখুন)"
                )
                return@launch
            } else {
                reconnectAttempts++
            }
            _state.value = _state.value.copy(statusMessageBn = "আবার সংযোগ হচ্ছে…")
            delay(700L)
            if (_state.value.isLiveActive && activeWebSocket == null) connectDirectBidiWebSocketIfPossible()
        }
    }

    private fun handleIncomingWebSocketJson(rawJson: String) {
        try {
            val root = JSONObject(rawJson)

            if (root.has("setupComplete")) {
                setupDone = true
                reconnectAttempts = 0
                _state.value = _state.value.copy(
                    connectionStatusLabel = "LIVE • ${wsBidiModel.removePrefix("models/")}",
                    statusMessageBn = "শুনছি… কথা বলুন"
                )
                return
            }
            root.optJSONObject("toolCall")?.let { handleToolCall(it); return }
            if (root.has("goAway")) {                       // server asks to reconnect soon
                activeWebSocket?.let { handleSocketDown(it, "goAway") }
                return
            }

            val sc = root.optJSONObject("serverContent") ?: return

            if (sc.optBoolean("interrupted", false)) {      // user spoke over the agent
                stopAndFlushLiveAudioTrack()
                modelTurnBuf.setLength(0)
                _state.value = _state.value.copy(
                    isAgentSpeakingLive = false,
                    isUserSpeakingBargeIn = true,
                    bargeInInterruptCount = _state.value.bargeInInterruptCount + 1
                )
                onBargeInInterruptRequested()
                return
            }

            sc.optJSONObject("inputTranscription")?.optString("text", "")?.takeIf { it.isNotBlank() }?.let {
                userTurnBuf.append(it)
                onUserTranscript(userTurnBuf.toString().trim())
            }
            sc.optJSONObject("outputTranscription")?.optString("text", "")?.takeIf { it.isNotBlank() }?.let {
                modelTurnBuf.append(it)
                onLiveSpokenChunkOrReply(modelTurnBuf.toString().trim(), false)
            }

            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                    val b64 = inline.optString("data", "")
                    if (inline.optString("mimeType", "").startsWith("audio/pcm") && b64.isNotBlank()) {
                        playPcm24kHzAudioChunk(b64)
                    }
                }
            }

            if (sc.optBoolean("turnComplete", false)) {
                userTurnBuf.setLength(0)
                modelTurnBuf.setLength(0)
                _state.value = _state.value.copy(isAgentSpeakingLive = false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "WS JSON parse warning: ${e.message}")
        }
    }

    /** Gemini asked to run a phone action -> execute it on-device and send the result back. */
    private fun handleToolCall(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        scope.launch {
            val responses = JSONArray()
            for (i in 0 until calls.length()) {
                val c = calls.optJSONObject(i) ?: continue
                val args = c.optJSONObject("args") ?: JSONObject()
                val tag = "[[ACTION:${args.optString("action").uppercase()}|${args.optString("target")}|${args.optString("extra")}]]"
                val result = try {
                    withTimeout(25_000L) { toolCallHandler?.invoke(tag) ?: "no handler" }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "error: ${e.message}"
                }
                recordLiveToolExecution("${args.optString("action")}: ${result.take(60)}")
                responses.put(JSONObject().apply {
                    put("id", c.optString("id"))
                    put("name", c.optString("name"))
                    put("response", JSONObject().put("result", result.take(1500)))
                })
            }
            try {
                activeWebSocket?.send(JSONObject().put("toolResponse",
                    JSONObject().put("functionResponses", responses)).toString())
            } catch (_: Exception) {}
        }
    }

    /**
     * Streams 24kHz 16-bit Mono PCM audio chunks over a shared `AudioTrack` (`MODE_STREAM`)
     * so audio plays back smoothly and can be halted instantaneously (`<10ms`) on barge-in.
     */
    private fun playPcm24kHzAudioChunk(base64Pcm: String) {
        try {
            val pcmBytes = Base64.decode(base64Pcm, Base64.DEFAULT)
            if (pcmBytes.isEmpty()) return

            synchronized(audioTrackLock) {
                var track = liveOutputAudioTrack
                if (track == null || track.state != AudioTrack.STATE_INITIALIZED) {
                    val sampleRate = 24000
                    val minBuf = AudioTrack.getMinBufferSize(
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    ).coerceAtLeast(4800)

                    track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(minBuf * 2)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                    liveOutputAudioTrack = track
                }

                if (track.playState != AudioTrack.PLAYSTATE_PLAYING) {
                    track.play()
                }
                _state.value = _state.value.copy(
                    isAgentSpeakingLive = true,
                    isUserSpeakingBargeIn = false
                )
                track.write(pcmBytes, 0, pcmBytes.size)
            }
        } catch (e: Exception) {
            Log.w(TAG, "PCM playback skip: ${e.message}")
        }
    }

    fun stopAndFlushLiveAudioTrack() {
        synchronized(audioTrackLock) {
            val track = liveOutputAudioTrack ?: return
            try {
                if (track.state == AudioTrack.STATE_INITIALIZED) {
                    track.pause()
                    track.flush()
                    track.stop()
                }
            } catch (_: Exception) {
            }
        }
    }

private fun sendRealtimeAudioChunkOverWs(pcm16kBytes: ByteArray) {
        val ws = activeWebSocket ?: return
        if (!setupDone || pcm16kBytes.isEmpty()) return
        try {
            val b64 = Base64.encodeToString(pcm16kBytes, Base64.NO_WRAP)
            ws.send(JSONObject().put("realtimeInput", JSONObject().put("audio",
                JSONObject().put("mimeType", "audio/pcm;rate=16000").put("data", b64))).toString())
        } catch (_: Exception) {
        }
    }

private fun sendRealtimeImageFrameOverWs(bitmap: Bitmap) {
        val ws = activeWebSocket ?: return
        if (!setupDone) return
        try {
            val b64 = encodeBitmapToBase64Jpeg(bitmap)
            ws.send(JSONObject().put("realtimeInput", JSONObject().put("video",
                JSONObject().put("mimeType", "image/jpeg").put("data", b64))).toString())
            _state.value = _state.value.copy(framesSentCount = _state.value.framesSentCount + 1)
        } catch (_: Exception) {
        }
    }

    private fun disconnectWebSocket() {
        try {
            activeWebSocket?.close(1000, "Session closed")
        } catch (_: Exception) {
        }
        activeWebSocket = null
    }

    /**
     * Executes a real-time Multimodal Live turn combining:
     * 1. User's spoken or typed utterance
     * 2. Live Camera bitmap (if Camera stream is enabled)
     * 3. Live Screen bitmap (from PermanentScreenCaptureService or Accessibility screenshot)
     * 4. Real-time device & screen accessibility telemetry
     */
    fun sendLiveMultimodalTurn(
        userUtterance: String,
        contextualDeviceState: String,
        isFrontCamera: Boolean
    ) {
        // Any new utterance from the user immediately interrupts prior speech (Barge-In)
        activeStreamTurnJob?.cancel()
        stopAndFlushLiveAudioTrack()

        activeStreamTurnJob = scope.launch {
            _state.value = _state.value.copy(
                isAgentSpeakingLive = true,
                isUserSpeakingBargeIn = false,
                liveStreamingPartialReply = "জি স্যার, দেখছি..."
            )

            val camFrame = if (_state.value.isCameraStreamEnabled) latestCameraBitmap else null

            // Capture fresh screen bitmap if Screen Stream is active
            if (_state.value.isScreenStreamEnabled) {
                ScreenCaptureSessionBus.captureBestAvailableScreenFrame { bmp ->
                    latestScreenBitmap = bmp
                }
            }
            val scrFrame = if (_state.value.isScreenStreamEnabled) {
                latestScreenBitmap ?: AccessibilityAutomationBus.renderLiveScreenMatrixBitmap()
            } else {
                null
            }

            // If Direct WebSocket Bidi is connected and preferred, also push clientContent over WS
            if (_state.value.isWebSocketConnected &&
                _state.value.connectionEngine == LiveConnectionEngine.DIRECT_WEBSOCKET_BIDI
            ) {
                try {
                    camFrame?.let { sendRealtimeImageFrameOverWs(it) }
                    scrFrame?.let { sendRealtimeImageFrameOverWs(it) }
                    val clientTurn = JSONObject().apply {
                        put(
                            "clientContent",
                            JSONObject().apply {
                                put(
                                    "turns",
                                    JSONArray().put(
                                        JSONObject().apply {
                                            put("role", "user")
                                            put(
                                                "parts",
                                                JSONArray().put(
                                                    JSONObject().put("text", "$contextualDeviceState\nUser: $userUtterance")
                                                )
                                            )
                                        }
                                    )
                                )
                                put("turnComplete", true)
                            }
                        )
                    }
                    activeWebSocket?.send(clientTurn.toString())
                    return@launch
                } catch (e: Exception) {
                    Log.w(TAG, "WS clientContent send failed, streaming via Built-In Firebase AI: ${e.message}")
                }
            }

            // Execute ultra-fast bounded-timeout Multimodal Live turn (Camera + Screen + Voice Context)
            try {
                val multimodalPrompt = content {
                    if (camFrame != null) {
                        image(scaleBitmapForLiveStream(camFrame))
                    }
                    if (scrFrame != null) {
                        image(scaleBitmapForLiveStream(scrFrame))
                    }
                    text(
                        buildString {
                            appendLine("=== GEMINI MULTIMODAL LIVE SESSION (VOICE + CAMERA + PERMANENT SCREEN) ===")
                            appendLine("Camera Stream Active: ${_state.value.isCameraStreamEnabled} (Lens: ${if (isFrontCamera) "FRONT" else "BACK"})")
                            appendLine("Permanent Screen Stream Active: ${_state.value.isScreenStreamEnabled}")
                            appendLine("Real-Time Phone Tools Armed: ${_state.value.isRealTimeToolsArmed}")
                            appendLine(contextualDeviceState)
                            appendLine("\nRespond naturally like a real human speaking in real-time (1-2 clear spoken sentences, NO markdown/lists), and include any required [[ACTION:...]] tag at the very end:")
                        }
                    )
                }

                var finalRaw = ""
                try {
                    finalRaw = withTimeout(6_000L) {
                        firebaseFastLiveModel.generateContent(multimodalPrompt).text?.trim().orEmpty()
                    }
                } catch (fastErr: Exception) {
                    if (fastErr is CancellationException && fastErr !is kotlinx.coroutines.TimeoutCancellationException) {
                        throw fastErr
                    }
                    Log.w(TAG, "Fast live model fallback to primary flash: ${fastErr.message}")
                }

                if (finalRaw.isBlank()) {
                    try {
                        finalRaw = withTimeout(6_500L) {
                            firebaseLiveStreamModel.generateContent(multimodalPrompt).text?.trim().orEmpty()
                        }
                    } catch (primaryErr: Exception) {
                        if (primaryErr is CancellationException && primaryErr !is kotlinx.coroutines.TimeoutCancellationException) {
                            throw primaryErr
                        }
                        Log.w(TAG, "Primary live model fallback to ViewModel engine: ${primaryErr.message}")
                    }
                }

                val cleanPreview = finalRaw.replace(Regex("\\[\\[ACTION:.*?]]"), "").trim()
                _state.value = _state.value.copy(
                    isAgentSpeakingLive = false,
                    liveStreamingPartialReply = cleanPreview,
                    streamedAudioPackets = _state.value.streamedAudioPackets + 1
                )
                onExecuteLiveActionTag(userUtterance, finalRaw)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Multimodal live turn error: ${e.message}")
                _state.value = _state.value.copy(isAgentSpeakingLive = false)
                onExecuteLiveActionTag(userUtterance, "")
            }
        }
    }

    private fun scaleBitmapForLiveStream(src: Bitmap): Bitmap {
        val maxDim = 384
        val w = src.width.coerceAtLeast(1)
        val h = src.height.coerceAtLeast(1)
        if (w <= maxDim && h <= maxDim) return src
        val ratio = maxDim.toFloat() / maxOf(w, h).toFloat()
        val nw = (w * ratio).toInt().coerceAtLeast(1)
        val nh = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, nw, nh, true)
    }

    private fun encodeBitmapToBase64Jpeg(bitmap: Bitmap): String {
        val scaled = scaleBitmapForLiveStream(bitmap)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 72, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    fun release() {
        stopLiveSession()
        synchronized(audioTrackLock) {
            try {
                liveOutputAudioTrack?.release()
            } catch (_: Exception) {
            }
            liveOutputAudioTrack = null
        }
    }

    companion object {
        val LIVE_MULTIMODAL_SYSTEM_PROMPT = """
            You are "ARCHER AI" (Cube AI / পার্সোনাল মোবাইল এজেন্ট), operating in real-time Gemini Live (`models/gemini-2.0-flash-exp`) Multimodal Mode with simultaneous Live Voice, Live Camera Video, and Permanent Live Screen Sharing.
            CRITICAL LIVE RULES:
            1. REAL HUMAN CONVERSATIONAL VOICE (NEVER SOUND LIKE YOU ARE READING TEXT):
               - Speak naturally, warmly, and conversationally like a real human companion talking face-to-face with "স্যার" (or "Sir" in English).
               - NEVER read out bullet points, numbered lists, markdown symbols (*, #, -), colons, or robotic announcements.
               - Use natural spoken Bengali rhythm (e.g., "জি স্যার, আমি স্ক্রিনে দেখছি...", "এক সেকেন্ড স্যার, এখনি করে দিচ্ছি", "হ্যাঁ স্যার, হয়ে গেছে") in 1–2 short, natural spoken sentences.
               - Strictly obey the user's Active Language Lock (e.g., ENGLISH_ONLY, BENGALI_ONLY, HINDI_ONLY) and Persistent Rules.
            2. PERMANENT LIVE SCREEN VISION & 4-DIRECTIONAL AUTONOMOUS TOUCH/CONTROL:
               - You have full access to the user's live screen image and accessibility node tree.
               - Whenever the user asks what is on the screen or asks you to click, scroll/swipe in any of the 4 directions (UP, DOWN, LEFT, RIGHT / উপরে, নিচে, ডানে, বামে), call someone, or toggle settings, inspect the screen and execute the action immediately!
            3. REAL-TIME PHONE TOOL EXECUTION:
               - Whenever the user asks to control the phone, CALL the `phone_action` tool (action, target, extra). Say a short natural sentence first, then call it. Never speak tags aloud.
               - Supported actions:
                 * TOGGLE_SYSTEM_SETTING (WIFI, BLUETOOTH, MOBILE_DATA, AIRPLANE, HOTSPOT, LOCATION, AUTO_ROTATE, DND, BATTERY_SAVER, DARK_MODE, FLASHLIGHT | ON or OFF)
                 * SET_VOLUME (ALL, MUSIC, RING, ALARM, NOTIFICATION, VOICE_CALL, SYSTEM | 0..100, UP, DOWN, MAX, MUTE, UNMUTE)
                 * SCAN_CONTACT_OR_SCREEN (PersonName | CALL or WHATSAPP or SCREEN_TAP)
                 * SCREEN_UI_CONTROL (target_text_or_coords | CLICK, SCROLL_DOWN, SCROLL_UP, SWIPE_UP, SWIPE_DOWN, SWIPE_LEFT, SWIPE_RIGHT, DOUBLE_TAP, LONG_PRESS, QUICK_SETTINGS, READ_SCREEN)
                 * GENERATE_CODE_PROJECT (project_title | filename.ext)
                 * OPEN_APP, INSTALL_APP_PLAYSTORE, PLAY_MUSIC, STOP_MUSIC, DIAL_NUMBER, OPEN_SETTINGS
        """.trimIndent()
    }
}
